/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication15;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class JavaFXApplication15 extends Application {

    Label guess = new Label("Guess Number:");
    TextField txtGuess = new TextField();
    Label result = new Label();
    int number = (int) (Math.random() * 101);

    @Override
    public void start(Stage primaryStage) {

        HBox hBox = new HBox(10);
        hBox.setPadding(new Insets(10, 10, 20, 10));
        hBox.getChildren().addAll(guess, txtGuess);
        HBox hBox1 = new HBox(10);
        Button check = new Button("Check");
        check.setOnAction(e -> {
            int GuessNumber = Integer.parseInt(txtGuess.getText());
            if (GuessNumber == number) {
                result.setText("True,You Did It!");
            } else if (GuessNumber > number) {
                result.setText("Too high");
            } else {
                result.setText("Too Low");
            }
        });
        hBox.getChildren().addAll(check);
        hBox.setAlignment(Pos.BOTTOM_CENTER);

        HBox hBox2 = new HBox(10);
        hBox.setPadding(new Insets(10, 10, 10, 10));
        hBox.getChildren().add(result);
        hBox.setAlignment(Pos.BOTTOM_CENTER);
        GridPane h = new GridPane();
        h.add(hBox, 0, 0);
        h.add(hBox1, 0, 1);
        h.add(hBox2, 1, 1);
        Scene scene = new Scene(h);
        primaryStage.setTitle("Guessing Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
